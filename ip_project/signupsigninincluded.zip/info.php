<?php
require "connection.php";
// echo $_GET['id'];
// echo '<br/>'; 
$sql="SELECT * FROM `sports` WHERE `sport_id` =".$_GET['id'].""; 
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result); 
$sport_name=$row["sport_name"];
$sport_desc=$row["sport_desc"]; 
$sport_time=$row["timing"];
$sport_quote=$row["Quotes"]; 
$sport_fees=$row["sport_fee"];
$sport_days=$row["days"]; // echo $row["sport_name"]; //to print sport name 
//echo '<br />'; 
// echo var_dump($result); 
// echo $row["sport_desc"]; `//to printsport title 
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $sport_name //title ?></title>
    <style>
        body {
            margin: 0px;
            padding: 0px;
            font-family: cursive;
            /* background-color: black; */
        }

        .cover_image {
            margin: 0px;
            height: 500px;
            width: 100%;
            /* border: 2px solid black; */
        }

        .sport_title {
            font-size: 50px;
            /* font-weight: bold; */
            position: absolute;
            top: 300px;
            left: 100px;
            color: white;
        }

        .sport_quote {
            font-size: 20px;
            font-weight: bold;
            font-style: italic;
            /* border: 2px solid black; */
            width: 800px;
            height: 80px;
            position: absolute;
            margin-top: 50px;
            left: 60px;
            font-family: "Arial Narrow Bold", sans-serif;
            /* top:20px; */
        }

        .sport_desc {
            display: inline-block;
            position: relative;
            /* border: 2px solid black; */
            left: 60px;
            width: 800px;
            margin-top: 160px;
            /* text-justify: ; */
        }

        .sport_time {
            position: relative;
            top: 20px;
            color: rgb(39, 46, 87);
            font-size: 19px;
            font-weight: bold;
        }

        .sport_fees {
            position: relative;
            top: 5px;
            font-weight: bold;
            color: rgb(39, 46, 87);;
            font-size: 19px;
        }

        .sport_days {
            position: relative;
            top: 5px;
            font-weight: bold;
            color: rgb(39, 46, 87);;
            font-size: 19px;
        }

        .sport_image {
            width: 430px;
            /* border: 2px solid black; */
            display: inline-block;
            height: 380px;
            position: relative;
            border-radius: 25px;
            left: 830px;
            box-shadow: 5px 10px rgb(119, 117, 117);
        }

        .more_images{
            /* border: 2px solid black; */
            display: inline-block;
            border: 2px solid red;
            border-radius: 20px;
            /* flex-direction: row; */
            /* left: 200px; */
            margin:20px;
            width: 250px;
            height: 180px;
            box-shadow: 10px 10px rgb(146, 146, 146);
        }
        .botoom_photos{
            /* border: 2px solid black; */
            position: relative;
            margin-left: 60px;
            margin-top: 60px;
            /* border: 2px solid red; */
            width: 1200px;
        }
        .container_about{
            max-width:100%;
        }
    </style>
</head>

<body>
    <div class="container_about">
    <div class="sport_title">
        <p>
            <?php
                echo $sport_name;
        ?>
        </p>
    </div>
    <div>
        <?php
        echo '<img class="cover_image" src="https://source.unsplash.com/1600x1200/?sport,'.$sport_name.'" alt ="cover_image">';
      ?>

        <div class="sport_quote">
            <p>
                <?php
        echo $sport_quote;
        ?>
            </p>

            <div>
                <?php
                echo'<img class="sport_image" src="/sports/images/cricket_cover.jpg" alt="image">';
          ?>
            </div>
        </div>
        <div class="sport_desc">
            <p>
                <?php
                echo $sport_desc;
                ?>
            </p>

            <div class="sport_time">
                <p>
                    <?php
                echo "Time : ".$sport_time."";
                ?>
                </p>
            </div>

            <div class="sport_fees">
                <p>
                    <?php
                echo "Fees : ".$sport_fees."";
                ?>
                </p>
            </div>

            <div class="sport_days">
                <p>
                    <?php
                echo "Days : ".$sport_days."";
                ?>
                </p>
            </div>
            
            <div class="botoom_photos">
                <img class="more_images" src="/sports/images/cricket_cover.jpg" alt="" />
                <img class="more_images" src="/sports/images/cricket_cover.jpg" alt="" />
                <img class="more_images" src="/sports/images/cricket_cover.jpg" alt="" />
                <img class="more_images" src="/sports/images/cricket_cover.jpg" alt="" />
            </div>
        </div>
    </div>
</div>
</body>

</html>